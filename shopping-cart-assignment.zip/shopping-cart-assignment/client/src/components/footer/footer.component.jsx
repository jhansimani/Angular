import React, { Component } from "react";
import "./footer.styles.scss";
export default class Footer extends Component {
  render() {
    return (
      <div className="footer">
        <p>
          Copyright &copy; 2011 &minus; 2018 Sabka Bazzar Grocery Supplies Pvt
          Ltd
        </p>
      </div>
    );
  }
}
